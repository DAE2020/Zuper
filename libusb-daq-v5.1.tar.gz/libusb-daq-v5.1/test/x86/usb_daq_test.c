#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <math.h>
//#include "usb_dll_v50.h"
typedef  char BYTE;

int OpenUsb(void);
int CloseUsb(void);
int WriteUsb(int dwPipeNum,char *pBuffer,int dwSize);
int ReadUsb(int dwPipeNum,char *pBuffer,int dwSize);

int DO_SOFT(BYTE chan,BYTE state);
BYTE DI_Soft(void);
int AD_single(int ad_os,int gain,float* adResult);
int AD_continu(int ad_os,int gain,int Num_Sample,int Rate_Sample,float* databuf);
int ElecPowerMeasure(int phase,int gain,float* databuf); 

int AD_continu_config(int ad_os,int gain,int Rate_Sample); 
int Get_AdBuff_Size(void);   
int Read_AdBuff(float* databuf,int num);
int AD_continu_stop(void);

int DA_sigle_out(int chan,int value);
int DA_DATA_SEND(int chan,int Num,int *databuf);
int DA_scan_out(int chan,int Freq,int scan_Num);
int PWM_Out(int chan,int Freq,int DutyCycle,int mod);
int PWM_In(int mod);
int COUNT(int mod);
int Read_PWM_In(float* Freq, int* DutyCycle);
int Read_COUNT(int* count);

 
#define pi 3.1415926
int  opened=0;

int main()
{  
     if(-1==OpenUsb())
	{
	  printf("####usb  device open fail ####\n");
	 return -1;
	}
	else
	{
       printf("####usb  device open ok  ####\n");
	}
      int i;  
      for(i=0;i<8;i++)
	{
	 DO_SOFT(i,1);
	}
        printf("####DusbEMO  device write Dout put 1  ####\n");
	unsigned char DI=0;
	DI=DI_Soft();
	 printf("####Din = %x\n",DI);

	int daResult,m_freq1,m_num1;
	 m_freq1=5000;
	m_num1=512;			
	 daResult=(int)(2*4096/3.3);
	 int *sine_wave; 
	//double phase = 0.0; 
	sine_wave = (int *)malloc(m_num1*sizeof(int));
	 for(i=0;i<m_num1;i++)
	 {
	  *(sine_wave+i)=(int)(sin(2*pi*i/m_num1)*daResult/2 +daResult/2);
	 }
	 DA_DATA_SEND(1,m_num1,sine_wave);
	DA_scan_out(1,m_freq1,m_num1);
       printf("####DusbEMO  device DA1 output sin wave  ####\n");
	 DA_sigle_out(2,(int)(2.5*4096/3.3));
        printf("####DusbEMO  device DA2 output 2.5V  ####\n");
	float ad[1024*8];
	if(AD_continu(0,1,1024,10000,ad)==0)
	{
	for(i=0;i<50;i++)
	{
	  printf("AD_continu ad[%d]=%f\n",i,ad[i*8]);
	}

	}
	else
	{
	 printf("AD_continu read ad fail!\n");
	}
 
	char str[10];
	float adResult1[8];
	
	
      if(AD_single(0,1,adResult1)==0)
	{
	for(i=0;i<8;i++)
         printf("AD_single read ad %d =%f\n",i,adResult1[i]);
	  
	}
	else
	{
	 printf("read ad %d fail!\n",i);
	}
	 
    
    CloseUsb();
    
 return 0;
}
