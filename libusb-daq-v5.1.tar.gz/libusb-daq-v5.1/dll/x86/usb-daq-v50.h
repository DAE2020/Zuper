
 
//#ifdef _cplusplus
extern "C"
{
//#endif
int OpenUsb(void);
int CloseUsb(void);
int WriteUsb(int dwPipeNum,char *pBuffer,int dwSize);
int ReadUsb(int dwPipeNum,char *pBuffer,int dwSize);

int DO_SOFT(char chan,char state);
char DI_Soft(void);
int AD_single(int ad_os,int gain,float* adResult);
int AD_continu(int ad_os,int gain,int Num_Sample,int Rate_Sample,float* databuf);
int ElecPowerMeasure(int phase,int gain,float* databuf); 

int AD_continu_config(int ad_os,int gain,int Rate_Sample); 
int Get_AdBuff_Size(void);   
int Read_AdBuff(float* databuf,int num);
int AD_continu_stop(void);

int DA_sigle_out(int chan,int value);
int DA_DATA_SEND(int chan,int Num,int *databuf);
int DA_scan_out(int chan,int Freq,int scan_Num);
int PWM_Out(int chan,int Freq,int DutyCycle,int mod);
int PWM_In(int mod);
int COUNT(int mod);
int Read_PWM_In(float* Freq, int* DutyCycle);
int Read_COUNT(int* count);
//#ifdef _cplusplus
}
//#endif
