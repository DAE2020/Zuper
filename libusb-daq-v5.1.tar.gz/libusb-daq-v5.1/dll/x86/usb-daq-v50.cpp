#include <stdio.h>
#include <string.h>
#include <sys/types.h>

#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>  
//#include <vector>
#include <list>
//#include <deque.h>
#include <queue>
#include <pthread.h>
//#include <linux/mutex.h>
#include"usb-daq-v50.h" 
#include <usb.h>           
//#include <mutex>


pthread_mutex_t mutex; //struct mutex		io_mutex;
pthread_t tid;
    int error;
int AD_scan_stop=0;
int ADerro=0;
 //stack<int> intstack;
 std::queue<float> AD_Data_Buf;
  //queue<float,deque<float>>  AD_Data_Buf;
void  *AD_ListenHandler(void *arg);
void* join_result;

usb_dev_handle *dev_h = NULL;  // the device handle
 
int DeviceCount;			 //�豸����
 
int  opened=0;
#define pi 3.1415926
#define MY_VID        0x7812
#define MY_PID        0x55A6
#define TRANSFER_TIMEOUT 6000 /* in msecs */
#define MY_CONFIG 1
#define MY_INTF 0
int verbose = 0;

void print_endpoint(struct usb_endpoint_descriptor *endpoint)
{
  printf("      bEndpointAddress: %02xh\n", endpoint->bEndpointAddress);
  printf("      bmAttributes:     %02xh\n", endpoint->bmAttributes);
  printf("      wMaxPacketSize:   %d\n", endpoint->wMaxPacketSize);
  printf("      bInterval:        %d\n", endpoint->bInterval);
  printf("      bRefresh:         %d\n", endpoint->bRefresh);
  printf("      bSynchAddress:    %d\n", endpoint->bSynchAddress);
}

void print_altsetting(struct usb_interface_descriptor *interface)
{
  int i;

  printf("    bInterfaceNumber:   %d\n", interface->bInterfaceNumber);
  printf("    bAlternateSetting:  %d\n", interface->bAlternateSetting);
  printf("    bNumEndpoints:      %d\n", interface->bNumEndpoints);
  printf("    bInterfaceClass:    %d\n", interface->bInterfaceClass);
  printf("    bInterfaceSubClass: %d\n", interface->bInterfaceSubClass);
  printf("    bInterfaceProtocol: %d\n", interface->bInterfaceProtocol);
  printf("    iInterface:         %d\n", interface->iInterface);

  for (i = 0; i < interface->bNumEndpoints; i++)
    print_endpoint(&interface->endpoint[i]);
}

void print_interface(struct usb_interface *interface)
{
  int i;

  for (i = 0; i < interface->num_altsetting; i++)
    print_altsetting(&interface->altsetting[i]);
}

void print_configuration(struct usb_config_descriptor *config)
{
  int i;

  printf("  wTotalLength:         %d\n", config->wTotalLength);
  printf("  bNumInterfaces:       %d\n", config->bNumInterfaces);
  printf("  bConfigurationValue:  %d\n", config->bConfigurationValue);
  printf("  iConfiguration:       %d\n", config->iConfiguration);
  printf("  bmAttributes:         %02xh\n", config->bmAttributes);
  printf("  MaxPower:             %d\n", config->MaxPower);

  for (i = 0; i < config->bNumInterfaces; i++)
    print_interface(&config->interface[i]);
}

int print_device(struct usb_device *dev, int level)
{
  usb_dev_handle *udev;
  char description[256];
  char string[256];
  int ret, i;

  udev = usb_open(dev);
  if (udev) {
    if (dev->descriptor.iManufacturer) {
      ret = usb_get_string_simple(udev, dev->descriptor.iManufacturer, string, sizeof(string));
      if (ret > 0)
        snprintf(description, sizeof(description), "%s - ", string);
      else
        snprintf(description, sizeof(description), "%04X - ",
                 dev->descriptor.idVendor);
    } else
      snprintf(description, sizeof(description), "%04X - ",
               dev->descriptor.idVendor);

    if (dev->descriptor.iProduct) {
      ret = usb_get_string_simple(udev, dev->descriptor.iProduct, string, sizeof(string));
      if (ret > 0)
        snprintf(description + strlen(description), sizeof(description) -
                 strlen(description), "%s", string);
      else
        snprintf(description + strlen(description), sizeof(description) -
                 strlen(description), "%04X", dev->descriptor.idProduct);
    } else
      snprintf(description + strlen(description), sizeof(description) -
               strlen(description), "%04X", dev->descriptor.idProduct);

  } else
    snprintf(description, sizeof(description), "%04X - %04X",
             dev->descriptor.idVendor, dev->descriptor.idProduct);

  printf("%.*sDev #%d: %s\n", level * 2, "                    ", dev->devnum,
         description);

  if (udev && verbose) {
    if (dev->descriptor.iSerialNumber) {
      ret = usb_get_string_simple(udev, dev->descriptor.iSerialNumber, string, sizeof(string));
      if (ret > 0)
        printf("%.*s  - Serial Number: %s\n", level * 2,
               "                    ", string);
    }
  }

  if (udev)
    usb_close(udev);

  if (verbose) {
    if (!dev->config) {
      printf("  Couldn't retrieve descriptors\n");
      return 0;
    }

    for (i = 0; i < dev->descriptor.bNumConfigurations; i++)
      print_configuration(&dev->config[i]);
  } else {
    for (i = 0; i < dev->num_children; i++)
      print_device(dev->children[i], level + 1);
  }

  return 0;
}
struct usb_device *device[16];

int Reset_Usb_Device(void)
{
  return usb_reset(dev_h);
}
int OpenUsb(void)
{
	if(opened==1)
	{
		CloseUsb();
		opened=0;
	}
	usb_init(); //initialize the library 
	usb_find_busses(); // find all busses 
	usb_find_devices(); // find all connected devices
	struct usb_bus *bus;
	struct usb_device *dev;
	int i=0,j;
	for (bus = usb_busses; bus; bus = bus->next) 
	{
		for (dev = bus->devices; dev; dev = dev->next)
		{
			 
			if (dev->descriptor.idVendor == MY_VID&& dev->descriptor.idProduct == MY_PID)
			{
				device[i]=dev;
				print_device(dev, 0);
				i++;
				if(i>=16)
					break;	
			}
		}
	}
	DeviceCount=i;
	if(i>0)
	{
		for( j=0;j<i;j++)
		{
			dev_h=usb_open(device[j]);
			//opened=1;
                      //  return 0;
		 	if (usb_set_configuration(dev_h, MY_CONFIG) < 0)
			{
				printf("error setting config #%d: %s\n", MY_CONFIG, usb_strerror());
				dev=NULL;
				continue;
			}
			if (usb_claim_interface(dev_h, MY_INTF) < 0)
			{
				printf("error claiming interface #%d:\n%s\n", MY_INTF, usb_strerror());
				dev=NULL;
				continue;
			}
			else
			{
				 
				printf("success: claim_interface #%d\n", MY_INTF);
				opened=1;
				return 0;
			}
                    
		}
	}
	dev=NULL;
	return -1;

}
int CloseUsb(void)
{
  if(opened==1)
	{
		opened=0;
		if(dev_h==NULL)
		{
			return-1;
		}
		usb_release_interface(dev_h, 0);
		if (dev_h)
		{
			usb_close(dev_h);
		}
		printf("Done.\n");
		return 0;
	}
	return -2;
}
 
int WriteUsb(int dwPipeNum,char *pBuffer,int dwSize)
{
int ret;
//printf("####write start####\n");
  ret = usb_bulk_write(dev_h, (int)dwPipeNum,(char *)pBuffer, dwSize,TRANSFER_TIMEOUT);
  if(ret>0)
	{
//	printf("####write end####\n");
	   return 0;
	}
  else
	  return 1;
	
}
int ReadUsb(int dwPipeNum,char *pBuffer,int dwSize)
{
	int ret;
//printf("####read start####\n");
  ret = usb_bulk_read(dev_h, (int)dwPipeNum,(char *)pBuffer, dwSize,TRANSFER_TIMEOUT);
  if(ret>0)
   {
//	printf("####read end####\n");
	   return 0;
	}
  else
	  return 1;
}

 
void  *AD_ListenHandler(void *arg)
{
  
int dwError;
   
	char pBuffer[1024];
   
 
 while(1)
 {

  
   ReadUsb(0x82,pBuffer,1024);
   if(AD_scan_stop)
   {
	 
	   break;
   }
   if (!dwError)
   {
	 pthread_mutex_lock (&mutex); // EnterCriticalSection (&critical_sec); 
	   for(int i=0;i<512;i++)
	   {
		//AD_buff[ad_scan_count++]=pBuffer[i];
		   AD_Data_Buf.push(10.0*((256*(signed char)pBuffer[i*2+1])+pBuffer[i*2])/32768);//10.0*((256*(signed char)pBuffer[i*2+1])+pBuffer[i*2])/32768
		 ADerro=0;

	   }
      pthread_mutex_unlock(&mutex);//  LeaveCriticalSection (&critical_sec); 
   }
   else
   {
     ADerro=1;
     
   }

 }

}
int Get_AdBuff_Size(void)  //-1 --- erro  0--buff empt 1--buff  full
{
	std::queue<float>::size_type bufSize;
	 pthread_mutex_lock (&mutex); //EnterCriticalSection (&critical_sec); 
   bufSize=AD_Data_Buf.size();
  pthread_mutex_unlock(&mutex);//  LeaveCriticalSection (&critical_sec); 
 // if(ADerro=1)return -1;
 return bufSize;
}
int Read_AdBuff(float* databuf,int num)
{
	int jj=0;
	 pthread_mutex_lock (&mutex); //EnterCriticalSection (&critical_sec); 
	for(jj=0;jj<num;jj++)
	{
       if(AD_Data_Buf.empty()==false)
	   {
       *databuf++=AD_Data_Buf.front();
 		AD_Data_Buf.pop();
	   }
	  else
	  {
	 	break;
	  }

	   }
	pthread_mutex_unlock(&mutex);// LeaveCriticalSection (&critical_sec); 
return jj;
}
int AD_continu_stop(void)
{
	 
   AD_scan_stop=1;
 // WDU_HaltTransfer(DrvCtx.pActiveDev->hDevice, 0x82);
  error=pthread_join(tid,&join_result); // ThreadWait(hThread);
  //  hThread = NULL;
  if(open==0)
	return -1;
  char buf[2];
   buf[0]=14;
  buf[1]=0;
 
 if(WriteUsb(0x1,buf,2))//停止扫描模式
   	return -1;
return 0;
}
int AD_single(int ad_os,int gain,float* adResult)
{
	if(open==0)
	return -1;
  char buf[16],inbuf[16];
 // EnterCriticalSection( &g_cs );
  if(gain>1)
	  gain=1;
  buf[0]=0;
  buf[1]=0;
 if(WriteUsb(0x1,buf,2))//设置模式 单次采样
   return -1;
  buf[0]=2;
  buf[1]=(char)gain;
  buf[2]=(char)ad_os;;
 if(WriteUsb(0x1,buf,3)) //设置
   return -1;

  buf[0]=1;
  buf[1]=1;
 if(WriteUsb(0x1,buf,2))//启动采集
  return -1;
 if(ReadUsb(0x82,inbuf,16)) //读取结果
   return -1;
   float v_adResult;
int jj;
   if(gain==0)
   {
	   for(jj=0;jj<8;jj++)
	   {
		   v_adResult=(float)(((signed char)inbuf[jj*2+1]*256)+inbuf[jj*2]);
        *(adResult+jj)=10.0*v_adResult/32768;
	   }
   }
   else
   {
     for(jj=0;jj<8;jj++)
	   {
		 v_adResult=(float)(((signed char)inbuf[jj*2+1]*256)+inbuf[jj*2]);
        *(adResult+jj)=5.0*v_adResult/32768;
	   }
   }
 // LeaveCriticalSection( &g_cs );

  return 0;
}
int AD_continu(int ad_os,int gain,int Num_Sample,int Rate_Sample,float* databuf)
{
	if((open==0)||(Rate_Sample>100000))
	return -1;
//	EnterCriticalSection( &g_cs );
   Num_Sample=Num_Sample*8;
	int num=0;
  char buf[16];
  char *inbuf;
  inbuf=(char  *)malloc(Num_Sample*2*sizeof(char )); 
  if(gain>1)
	  gain=1;
  buf[0]=0;
  buf[1]=1;
 if(WriteUsb(0x1,buf,2))//设置模式 单次采样
   return -1;
  buf[0]=2;
  buf[1]=(char)gain;
  buf[2]=(char)ad_os;
 if(WriteUsb(0x1,buf,3)) //设置
   return -1;

  buf[0]=3;
  buf[1]=Rate_Sample&0xff;
  buf[2]=(Rate_Sample>>8)&0xff;
  buf[3]=(Rate_Sample>>16)&0xff;
  buf[4]=(Rate_Sample>>24)&0xff;
  if(WriteUsb(0x1,buf,5)) //设置采样频率
   	return -1;
  buf[0]=4;
  Num_Sample=Num_Sample-Num_Sample%32;
  if(Num_Sample<0)Num_Sample=0;
  buf[1]=Num_Sample&0xff;
  buf[2]=(Num_Sample>>8)&0xff;
  buf[3]=(Num_Sample>>16)&0xff;
  buf[4]=(Num_Sample>>24)&0xff;
  if(WriteUsb(0x1,buf,5)) //设置采样个数
    	return -1;

  buf[0]=1;
  buf[1]=1;
 // 
 if(WriteUsb(0x1,buf,2))//启动采集
   	return -1;
  
 
   
//for(int j=0;j<Num_Sample/1024;j++)
//{
 if(ReadUsb(0x82,inbuf,Num_Sample*2)) //读取结果
  	return -1;
int i;
  for(i=0;i<Num_Sample;i++)
  {	 
		 if(gain==0)
	   {
		  
			 *databuf=10.0*((256*(signed char)inbuf[i*2+1])+inbuf[i*2])/32768;
		
	   }
	   else
	   {
		 
			 *databuf=5.0*((256*(signed char)inbuf[i*2+1])+inbuf[i*2])/32768;
		   
	   }  	 
  // *databuf=(((short)inbuf[i*2+1]<<8)|(short)inbuf[i*2]);
   databuf++;
  }
//}
//LeaveCriticalSection( &g_cs );
return 0;
}
int ElecPowerMeasure(int phase,int gain,float* databuf)
{
	int Num_Sample=512;
	int Rate_Sample=2000;
	if((open==0)||(Rate_Sample>100000))
	return -1;
//	EnterCriticalSection( &g_cs );
   Num_Sample=Num_Sample*8;
	int num=0;
  char buf[16];
  char *inbuf;
  inbuf=(char  *)malloc(Num_Sample*2*sizeof(char )); 
  if(gain>1)
	  gain=1;
  buf[0]=0;
  buf[1]=2;
 if(WriteUsb(0x1,buf,2))//设置模式 单次采样
   return -1;
  buf[0]=2;
  buf[1]=(char)gain;
  buf[2]=0;
 if(WriteUsb(0x1,buf,3)) //设置
   return -1;

  buf[0]=3;
  buf[1]=Rate_Sample&0xff;
  buf[2]=(Rate_Sample>>8)&0xff;
  buf[3]=(Rate_Sample>>16)&0xff;
  buf[4]=(Rate_Sample>>24)&0xff;
  if(WriteUsb(0x1,buf,5)) //设置采样频率
   	return -1;
  buf[0]=4;
  Num_Sample=Num_Sample-Num_Sample%32;
  if(Num_Sample<0)Num_Sample=0;
  buf[1]=Num_Sample&0xff;
  buf[2]=(Num_Sample>>8)&0xff;
  buf[3]=(Num_Sample>>16)&0xff;
  buf[4]=(Num_Sample>>24)&0xff;
  if(WriteUsb(0x1,buf,5)) //设置采样个数
    	return -1;
  buf[0]=5;
  if(phase<0)phase=0;
  buf[1]=phase&0xff;
  buf[2]=(phase>>8)&0xff;
  if(WriteUsb(0x1,buf,3)) //设置相位
    	return -1;

  buf[0]=1;
  buf[1]=1;
 // 
 if(WriteUsb(0x1,buf,2))//启动采集
   	return -1;
  
 
   
//for(int j=0;j<Num_Sample/1024;j++)
//{
 if(ReadUsb(0x82,inbuf,Num_Sample*2)) //读取结果
  	return -1;
int i;
  for( i=0;i<3200;i++)
  {	 
		 if(gain==0)
	   {
		  
		//	*databuf=10.0*((256*(signed short)inbuf[i*2+1])+inbuf[i*2])/32768;
			 *databuf=10.0*((256*(signed char)inbuf[i*2+1])+inbuf[i*2])/32768;
		
	   }
	   else
	   {
		 
			*databuf=5.0*((256*(signed short)inbuf[i*2+1])+inbuf[i*2])/32768;
		   
	   }  	 
  // *databuf=(((short)inbuf[i*2+1]<<8)|(short)inbuf[i*2]);
   databuf++;
  }
//}
//LeaveCriticalSection( &g_cs );
return 0;
}

int AD_continu_config(int ad_os,int gain,int Rate_Sample)
{
	if((open==0)||(Rate_Sample>100000))
	return -1;
//	EnterCriticalSection( &g_cs );
  if(gain>6)
	  return -1;

	int num=0;
  char buf[16];
 buf[0]=0;
  buf[1]=1;
 if(WriteUsb(0x1,buf,2))//设置模式 单次采样
   return -1;
  buf[0]=2;
  buf[1]=(char)gain;
  buf[2]=(char)ad_os;
 if(WriteUsb(0x1,buf,3)) //设置
   return -1;

  buf[0]=3;
  buf[1]=Rate_Sample&0xff;
  buf[2]=(Rate_Sample>>8)&0xff;
  buf[3]=(Rate_Sample>>16)&0xff;
  buf[4]=(Rate_Sample>>24)&0xff;
  if(WriteUsb(0x1,buf,5)) //设置采样频率
   	return -1;
  buf[0]=4;
  buf[1]=0;
  buf[2]=0;
  buf[3]=0;
  buf[4]=0;
  if(WriteUsb(0x1,buf,5)) //设置采样个数
    	return -1;
 
  buf[0]=14;
  buf[1]=1;
 // 
 if(WriteUsb(0x1,buf,2))//启动扫描模式
   	return -1;
  buf[0]=1;
  buf[1]=1;
 // 
 if(WriteUsb(0x1,buf,2))//启动采集
   	return -1;
 //mutex_init(io_mutex);//InitializeCriticalSection(&critical_sec); 
 AD_scan_stop=0;
  error=pthread_create(&tid,NULL,AD_ListenHandler,NULL);///ThreadStart(&hThread, AD_ListenHandler, NULL);
 return 0;
}

int DA_sigle_out(int chan,int value)
{
   if(open==0)
	return -1;
  char buf[16];
  if(chan==1)
  {
  buf[0]=7;
  }
  else
  {
   buf[0]=8;
  }
  buf[1]=0;//da mod
  buf[2]=0;//da num
  buf[3]=0;

  buf[4]=0;//da freq
  buf[5]=0;
  buf[6]=0;
  buf[7]=0;

  buf[8]= value&0xff;  //da value
  buf[9]=(value>>8)&0xff;
   
  if(WriteUsb(0x1,buf,10)) //设置采样频率
   return -1;

	return 0;
}
void delay(int ii)
{
 
 while(1)
 {
  ii--;
 if(ii<1)break;
 }
}
int DA_DATA_SEND(int chan,int Num,int *databuf)
{
  	if(open==0)
	return -1;
    char buf2[64];
  int aa=0,bb=0;
  int i,j;
  if(Num>512)Num=512;
  aa=Num/30;
  bb=Num%30;
  buf2[0]=32;
  buf2[1]=0;
 /*   for(j=2;j<10;j++)
 {
  buf2[j]=j;
   }
  if(WriteUsb(0x2,buf2,10))  
	   return -1;
 */
  buf2[0]=32;
  buf2[1]=0;
  if(aa>0)
  {
	  for(i=0;i<aa;i++)
	  {
		  if(chan==1)
		  {
	   buf2[2]=(i*30)&0xff;
	   buf2[3]=((i*30)>>8)&0xff;
		  }
		  else
		  {
		buf2[2]=(i*30+512)&0xff;
		buf2[3]=((i*30+512)>>8)&0xff;
		  }
	   for(j=0;j<30;j++)
	   {
		buf2[(j<<1)+4]=(*(databuf+i*30+j))&0xff;
		buf2[(j<<1)+5]=((*(databuf+i*30+j))>>8)&0xff;
	   }
	  if(WriteUsb(0x1,buf2,64)) 
	   return -1;
      // delay(1000000);
	  }
  }
  if(bb>0)
  {
     if(chan==1)
		  {
	   buf2[2]=(aa*30)&0xff;
	   buf2[3]=((aa*30)>>8)&0xff;
		  }
		  else
		  {
		buf2[2]=(aa*30+512)&0xff;
		buf2[3]=((aa*30+512)>>8)&0xff;
		  }
	   for(j=0;j<bb;j++)
	   {
		buf2[(j<<1)+4]=(*(databuf+aa*30+j))&0xff;
		buf2[(j<<1)+5]=((*(databuf+aa*30+j))>>8)&0xff;
	   }
	  if(WriteUsb(0x1,buf2,(bb<<1)+4)) 
	   return -1;
     // delay(1000000);
  }
  
  return 0;
}
int DA_scan_out(int chan,int Freq,int scan_Num)
{
	if(open==0)
	return -1;
 

  char buf[16];
  if(chan==1)
  {
  buf[0]=7;
  }
  else
  {
   buf[0]=8;
  }
  buf[1]=1;//da mod
  buf[2]=scan_Num&0xff;//da num
  buf[3]=(scan_Num>>8)&0xff;

  buf[4]=Freq&0xff;//da freq
  buf[5]=(Freq>>8)&0xff;
  buf[6]=(Freq>>16)&0xff;
  buf[7]=(Freq>>24)&0xff;

  buf[8]=0;  //da value
  buf[9]=0;
   
  if(WriteUsb(0x1,buf,10))  
   return -1;
	return 0;
}
int PWM_Out(int chan,int Freq,int DutyCycle,int mod)
{

	if(open==0)
	return -1;
char buf[16];
  if(chan==1)
  {
  buf[0]=9;
  }
  else
  {
   buf[0]=10;
  }
  buf[1]=mod;//pwm mod
  buf[2]=DutyCycle&0xff;//PWM_Duty-- 二个bit
  buf[3]=(DutyCycle>>8)&0xff;

  buf[4]=Freq&0xff;//PWM_Freq--四个bit
  buf[5]=(Freq>>8)&0xff;
  buf[6]=(Freq>>16)&0xff;
  buf[7]=(Freq>>24)&0xff;

  if(WriteUsb(0x1,buf,8))  
   return -1;
	return 0;
}
int PWM_In(int mod)
{

	if(open==0)
	return -1;
 char buf[2];
  buf[0]=11;
  buf[1]=mod;
 if(WriteUsb(0x1,buf,2))// 
   return -1;

	return 0;
}
int COUNT(int mod)
{

	if(open==0)
	return -1;
  char buf[2];
  buf[0]=12;
  buf[1]=mod;
 if(WriteUsb(0x1,buf,2))// 
   return -1;
	return 0;
}
int Read_PWM_In(float* Freq, int* DutyCycle)
{

	if(open==0)
	return -1;
	char inbuf[16];
   if(ReadUsb(0x81,inbuf,16)) //读取结果
   return -1;
   if(ReadUsb(0x81,inbuf,16)) //读取结果
   return -1;
   * DutyCycle=inbuf[1];
   * DutyCycle+=(unsigned int)inbuf[2]<<8;
   int freq1;
   freq1=inbuf[3];
   freq1+=(unsigned int)inbuf[4]<<8;
   freq1+=(unsigned int)inbuf[5]<<16;
   freq1+=(unsigned int)inbuf[6]<<24;
   * Freq=(float)freq1/10;
	return 0;
}
int Read_COUNT(int* count)
{

	if(open==0)
	return -1;
	char inbuf[16];
   if(ReadUsb(0x81,inbuf,16)) //读取结果
   return -1;
   if(ReadUsb(0x81,inbuf,16)) //读取结果
   return -1;
   
   * count=inbuf[7];
   * count+=(unsigned int)inbuf[8]<<8;
   * count+=(unsigned int)inbuf[9]<<16;
   * count+=(unsigned int)inbuf[10]<<24;
	return 0;
}
int DO_SOFT(char chan,char state)
{
   if(open==0)
	return -1;
  char buf[3];
  buf[0]=13;
  buf[1]=chan;
  buf[2]=state;
 if(WriteUsb(0x1,buf,3))// 
   return -1;
	return 0;
}
char DI_Soft(void)
{
  if(open==0)
	return -1;
	char inbuf[16];
   if(ReadUsb(0x81,inbuf,16)) //读取结果
   return -1;
   if(ReadUsb(0x81,inbuf,16)) //读取结果
   return -1;
   
   return inbuf[0];
   
 
}

